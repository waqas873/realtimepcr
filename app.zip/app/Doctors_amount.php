<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doctors_amount extends Model
{
    //
}
