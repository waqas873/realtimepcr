<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Profile_test extends Model
{
    //
}
