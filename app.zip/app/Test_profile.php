<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Test_profile extends Model
{
    //
}
