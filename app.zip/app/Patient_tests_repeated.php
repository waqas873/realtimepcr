<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Patient_tests_repeated extends Model
{
    protected $table = 'patient_tests_repeated';
}
