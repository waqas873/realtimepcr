$(document).ready(function(){

$('[data-toggle="tooltip"]').tooltip();

$(document).on('click', '#addTest', function (e) {
  $('#addTestModal').modal("show");
});

$(document).on('click', '.invoice_id', function (e) {
  var invoice_id = $(this).attr('rel');
  $('.all_errors').empty();
  $.ajax({
      url: 'invoice_detail/'+invoice_id,
      type: 'GET',
      dataType: 'JSON',
      success: function (data) {
        if(data.response){
          $('#inv_id').html(data.inv_id);
          $('#inv_date').html(data.date);
          $('#tests_detail').html(data.tests);
          $('#total_details').html(data.total_details);
          $('#patient_name').html(data.patient_name);
          // $('#inv_id').html(data.inv_id);
          $('#invoiceModal').modal('show');
        }
      }
  });
});

$('#datatable').DataTable({
  "order": [
      [0, 'desc']
  ]
});

});