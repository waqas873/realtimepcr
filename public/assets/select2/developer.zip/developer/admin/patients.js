$(document).ready(function(){

var contact_no_exist = false;

$(document).on('click', '.update_btn', function (e) {
  $('#update-form').submit();
});

$(document).on('submit', '#update-form', function (e) {
  e.preventDefault();
  var obj = $(this);
  $('.all_errors').empty();

  var formData = obj.serializeArray();
  var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
  formData.push({'name':'_token','value':CSRF_TOKEN});
  $.ajax({
      url: '/admin/process-patient-update',
      type: 'POST',
      data: formData,
      dataType: 'JSON',
      success: function (data) {
        if(data.response){

          swal({
            title: "Success",
            text: "Patient has been registered successfully.",
            icon: "success",
            button: "OK",
          });
          
        }
        else{
          $('#name_error').html(data.name);
          $('#cnic_error').html(data.cnic);
          $('#contact_no_error').html(data.contact_no);
          $('#email_error').html(data.email);
          $('#passport_no_error').html(data.passport_no);
          $('#airline_error').html(data.airline);
          $('#collection_point_error').html(data.collection_point);
          $('#flight_date_error').html(data.flight_date);
          $('#flight_time_error').html(data.flight_time);
        }
      }
  });
});

$(document).on('keyup', '#contact_no', function (e) {
  var contact_no = $(this).val();
  $('#contact_no_error').empty();
  $.ajax({
      url: '/contact_no_exist/'+contact_no,
      type: 'GET',
      dataType: 'JSON',
      success: function (data) {
        if(data.response){
          $('#contact_no_error').html("This contact no is already registered.");
          contact_no_exist = true;
        }
        else{
          contact_no_exist = false;
        }
      }
  });
});

$('#datatable').DataTable({
  "order": [
      [0, 'sesc']
  ],
});

});