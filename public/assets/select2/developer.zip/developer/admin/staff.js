$(document).ready(function(){

$(document).on('click', '#add_lab_user', function (e) {
  //$('#add-lab-user-form').trigger("reset");
  $('#addLabUserModal').modal("show");
});

$(document).on('click', '#add_cp_user', function (e) {
  //$('#add-lab-user-form').trigger("reset");
  $('#addCpUserModal').modal("show");
});

$(document).on('submit', '#add-lab-user-form', function (e) {
  e.preventDefault();
  var obj = $(this);
  $('.all_errors').empty();
  var formData = obj.serializeArray();
  var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
  formData.push({'name':'_token','value':CSRF_TOKEN});
  $.ajax({
      url: '/admin/add-lab-user',
      type: 'POST',
      data: formData,
      dataType: 'JSON',
      success: function (data) {
        if(data.response){
          obj.trigger("reset");
          $('#addLabUserModal').modal('hide');

          swal("Lab employee added successfully.")
          .then((value) => {
            location.reload();
          });

        }
        else{
          if(data.username_exist){
            swal({
              title: "Warning",
              text: "This username has been already taken.Please try another one.",
              icon: "error",
              button: "OK",
            });
          }
          else{
            $('#lab_id_error').html(data.lab_id);
            $('#role_error').html(data.role);
            $('#name_error').html(data.name);
            $('#cnic_error').html(data.cnic);
            $('#contact_no_error').html(data.contact_no);
            $('#username_error').html(data.username);
            $('#password_error').html(data.password);
            $('#pay_error').html(data.pay);
          }
        }
      }
  });
});

$(document).on('submit', '#add-collection-point-form', function (e) {
  e.preventDefault();
  var obj = $(this);
  $('.all_errors').empty();
  var formData = obj.serializeArray();
  var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
  formData.push({'name':'_token','value':CSRF_TOKEN});
  $.ajax({
      url: '/admin/add-cp-user',
      type: 'POST',
      data: formData,
      dataType: 'JSON',
      success: function (data) {
        if(data.response){
          obj.trigger("reset");
          $('#addCpUserModal').modal('hide');

          swal("Collection Point Operator added successfully.")
          .then((value) => {
            location.reload();
          });

        }
        else{
          if(data.username_exist){
            swal({
              title: "Warning",
              text: "This username has been already taken.Please try another one.",
              icon: "error",
              button: "OK",
            });
          }
          else{
            $('#cp_collection_point_id_error').html(data.cp_collection_point_id);
            $('#cp_name_error').html(data.cp_name);
            $('#cp_contact_no_error').html(data.cp_contact_no);
            $('#cp_username_error').html(data.cp_username);
            $('#cp_password_error').html(data.cp_password);
          }
        }
      }
  });
});

$('#datatable').DataTable({
  
});

$('#datatable2').DataTable({
  
});

$('#patients_datatable').DataTable({
  "ordering": true,
  "lengthChange": true,
  "searching": true,
  "processing":true,
  "serverSide": true,
  "ajax": {
      url: base_url + '/admin/staff-patients',
      type: 'POST',
      "data": function (d) {
          return $.extend({}, d, {
            "_token": $('meta[name="csrf-token"]').attr('content'),
            "user_id": $('#user_id').val(),
            "from_date": $('#from_date').val(),
            "to_date": $('#to_date').val()
          });
      } 
  },
  "order": [
      [0, 'asc']
  ],
  columnDefs: [
    {'targets': 0, 'orderable': false},
    {'targets': 1, 'orderable': false},
    {'targets': 2, 'orderable': false},
    {'targets': 3, 'orderable': false},
    {'targets': 4, 'orderable': false}
  ],
  "columns": [
    {"data": "created_at"},
    {"data": "id"},
    {"data": "name"},
    {"data": "cnic"},
    {"data": "contact_no"},
    {"data": "invoices"}
  ]
});

$(document).on('click', '#by_date', function (e) {
 $('#patients_datatable').DataTable().ajax.reload();  
});

});